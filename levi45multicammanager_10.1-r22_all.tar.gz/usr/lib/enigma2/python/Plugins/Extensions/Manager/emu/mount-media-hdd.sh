#!/bin/sh
#DESCRIPTION=This script created by Levi45\nMount media/hdd to /dev/sd1
mount /dev/sda1 /media/hdd
echo "/media/hdd mounted to /dev/sda1"
exit 0