#!/bin/sh
#DESCRIPTION=This script moded by Levi45\nSystem
[ ! -d "/etc/enigma2/whitelist_streamrelay" ] && wget -O /etc/enigma2/whitelist_streamrelay http://levi45.spdns.eu/Addons/Multicam/Arm/whitelist_streamrelay
