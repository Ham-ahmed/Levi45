# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/SatVenusPanel/__init__.py
pass